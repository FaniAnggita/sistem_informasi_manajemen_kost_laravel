
<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <!-- Columns start at 50% wide on mobile and bump up to 33.3% wide on desktop -->
    <div class="row">
        <div class="col-sm-6 mb-4">
            <h1 class="m-0">Dashboard</h1>
        </div><!-- /.col -->
    </div><!-- /.row -->
    <div class="row">
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="card bg-info mb-3 text-white">
                <div class="card-header">
                    <h3><?php $__currentLoopData = $kamar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($k->total); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h3>
                    <p>Kamar</p>
                </div>
                <div class="icon">
                    <i class="ion ion-bag"></i>
                </div>
                <a href="/admin/kamar" class="card-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="card bg-success mb-3 text-white">
                <div class="card-header">
                    <h3><?php $__currentLoopData = $penghuni_kost_aktif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($k->total); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h3>
                    <p>Penghuni Kost Aktif</p>
                </div>
                <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                </div>
                <a href="/admin/pesanan" class="card-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="card bg-warning mb-3 text-white">
                <div class="card-header">
                    <h3><?php $__currentLoopData = $penghuni_kost_nonaktif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($k->total); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h3>
                    <p>Penghuni Kost Nonaktif</p>
                </div>
                <div class="icon">
                    <i class="ion ion-person-add"></i>
                </div>
                <a href="/admin/pesanan" class="card-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="card bg-danger mb-3 text-white">
                <div class="card-header">
                    <h3><?php $__currentLoopData = $budget; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($k->total); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><sup style="font-size: 15px"> /tahun</sup></h3>

                    <p>Budget</p>
                </div>
                <div class="icon">
                    <i class="ion ion-pie-graph"></i>
                </div>
                <a href="/admin/laporan" class="card-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
    </div>

    <!-- Bagain Table -->
    <div class="row mt-3">
        <h4>Penghuni Kost</h4>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Foto</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Email</th>
                    <th scope="col">Kontak</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Kamar Kost</th>
                    <th scope="col">Harga Sewa/ bulan</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $penghuni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><img src="/foto_penghuni/<?php echo e($p->foto_profil); ?>" alt="penghuni" style="width:50px"></td>
                    <td><?php echo e($p->nama_penghuni); ?></td>
                    <td><?php echo e($p->email); ?></td>
                    <td><?php echo e($p->kontak); ?></td>
                    <td><?php echo e($p->alamat); ?></td>
                    <td><?php echo e($p->nama_kamar); ?></td>
                    <td><?php echo e($p->harga); ?></td>
                    <td><?php echo e($p->status_penghuni); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Temporary\kost\resources\views/admin/beranda.blade.php ENDPATH**/ ?>