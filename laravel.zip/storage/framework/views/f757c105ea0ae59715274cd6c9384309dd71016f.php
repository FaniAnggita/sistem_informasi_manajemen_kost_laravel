
<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <a href="<?php echo e(route('kamar.index')); ?>" class="btn btn-warning btn-sm"> <span data-feather="arrow-left-circle"> </span> Batal</a>
                <h2>Detail Kamar: <?php echo e($kamar->nama_kamar); ?></h2>
            </div>
            <hr>
            <div class="col-6">
                <img src="/foto_kamar/<?php echo e($kamar->foto); ?>" alt="kamar" style="width: 100%">
            </div>
            <div class="col-6">
                <table class="table table-bordered table-striped">
                    <tr>
                        <th scope="row">ID</th>
                        <td><?php echo e($kamar->id); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Nama Kamar</th>
                        <td><?php echo e($kamar->nama_kamar); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Harga</th>
                        <td><?php echo e($kamar->harga); ?><small>/ bulan</small></td>
                    </tr>
                    <tr>
                        <th scope="row">Status</th>
                        <td><?php echo e($kamar->status); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Panjang </th>
                        <td><?php echo e($kamar->panjang); ?> <small>m</small></td>
                    </tr>
                    <tr>
                        <th scope="row">Lebar </th>
                        <td><?php echo e($kamar->lebar); ?> <small>m</small></td>
                    </tr>
                    <tr>
                        <th scope="row">Kapasitas </th>
                        <td><?php echo e($kamar->kapasitas); ?> <small>orang</small></td>
                    </tr>
                    <tr>
                        <th scope="row">Keterangan</th>
                        <td><?php echo e($kamar->keterangan); ?></td>
                    </tr>
                </table>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Temporary\kost\resources\views/admin/kamar/show.blade.php ENDPATH**/ ?>