
<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <div class="container">
        <div>
            <h2>Daftar Kamar Kost</h2>
        </div>
        <?php if($message = Session::get('message')): ?>
        <div class="alert alert-warning alert-dismissible fade show text-center" role="alert">
            <strong>
                <p><?php echo e($message); ?></p>
            </strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col">
                <a href="<?php echo e(route('kamar.create')); ?>" class="btn btn-primary btn-sm"> <span data-feather="plus-circle"></span> Kamar Baru</a>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nama Kamar</th>
                            <th scope="col">Status</th>
                            <th scope="col">Harga</th>
                            <th scope="col">Kapasitas</th>
                            <th scope="col">Ukuran</th>
                            <th scope="col">Foto</th>
                            <th scope="col">Keterangan</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $kamar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($k->nama_kamar); ?></td>
                            <td><?php echo e($k->status); ?></td>
                            <td><?php echo e($k->harga); ?></td>
                            <td><?php echo e($k->kapasitas); ?></td>
                            <td><?php echo e($k->panjang); ?>x<?php echo e($k->lebar); ?></td>
                            <td> <img src="/foto_kamar/<?php echo e($k->foto); ?>" alt="kamar" style="width:150px"></td>
                            <td><?php echo e($k->keterangan); ?></td>
                            <td>

                                <a href="<?php echo e(route('kamar.show', $k->id)); ?>" class="badge bg-info"> <i class="bi bi-eye"></i></i></a>
                                <a href="<?php echo e(route('kamar.edit', $k->id)); ?>" class="badge bg-warning"> <i class="bi bi-pencil-square"></i></i></a>
                                <a href='delete/<?php echo e($k->id); ?>' class="badge bg-danger" onclick="return confirm('Apakah anda yakin untuk menghapusnya?');"> <i class="bi bi-trash"></i>/a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Temporary\kost\resources\views/admin/kamar/kamar.blade.php ENDPATH**/ ?>