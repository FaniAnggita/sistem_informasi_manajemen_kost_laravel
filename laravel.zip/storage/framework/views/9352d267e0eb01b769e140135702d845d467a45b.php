
<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <div class="container">
        <div>
            <h2>Daftar Penghuni Kost</h2>
        </div>
        <?php if($message = Session::get('message')): ?>
        <div class="alert alert-warning alert-dismissible fade show text-center" role="alert">
            <strong>
                <p><?php echo e($message); ?></p>
            </strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col">
                <a href="<?php echo e(route('pesanan.create')); ?>" class="btn btn-primary btn-sm"> <span data-feather="plus-circle"></span> Tambah Penghuni Kost Baru</a>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Foto</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Email</th>
                            <th scope="col">Kontak</th>
                            <th scope="col">Alamat</th>
                            <th scope="col">Kamar Kost</th>
                            <th scope="col">Harga Sewa/ bulan</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $penghuni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><img src="/foto_penghuni/<?php echo e($p->foto_profil); ?>" alt="penghuni" style="width:50px"></td>
                            <td><?php echo e($p->nama_penghuni); ?></td>
                            <td><?php if($p->gender == 1): ?> Pria <?php else: ?> Wanita <?php endif; ?></td>
                            <td><?php echo e($p->email); ?></td>
                            <td><?php echo e($p->kontak); ?></td>
                            <td><?php echo e($p->alamat); ?></td>
                            <td><?php echo e($p->nama_kamar); ?></td>
                            <td><?php echo e($p->harga); ?></td>
                            <td><?php echo e($p->status_penghuni); ?></td>
                            <td class="d-flex gap-2">
                                <a href="<?php echo e(route('pesanan.edit', $p->penghuni_kost_id)); ?>" class="badge bg-warning"> <i class="bi bi-pencil-square"></i></a>
                                <a href='/admin/pesanan/delete/<?php echo e($p->penghuni_kost_id); ?>' class="badge bg-danger" onclick="return confirm('Apakah anda yakin untuk menghapusnya?');"> <i class="bi bi-trash"></i></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Temporary\kost\resources\views/admin/pesanan/index.blade.php ENDPATH**/ ?>