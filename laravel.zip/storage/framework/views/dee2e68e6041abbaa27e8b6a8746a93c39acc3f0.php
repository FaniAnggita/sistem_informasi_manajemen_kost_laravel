<header class="navbar navbar-dark sticky-top bg-primary flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">Manajemen Kost</a>
    <div class="row text-white">
        <div class="col-2"> <button class="navbar-toggler d-md-none collapsed me-3" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
                <i class="bi bi-list"></i>
            </button>
        </div>

        <div class="col-2 ms-4">
            <div class="navbar-nav">
                <div class="nav-item text-nowrap">
                    <a class="nav-link px-3" href="/logout"><i class="bi bi-box-arrow-right me-2 text-white"></i>Logout</a>
                </div>
            </div>
        </div>
    </div>

</header><?php /**PATH D:\Temporary\kost\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>